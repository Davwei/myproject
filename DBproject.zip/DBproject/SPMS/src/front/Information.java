package front;

import javax.swing.JPanel;
import javax.swing.JLabel;

public class Information extends JPanel {

	/**
	 * Create the panel.
	 */
	public Information() {
		
		JLabel lblNewLabel = new JLabel("\u7CFB\u7EDF\u6682\u672A\u4E0A\u7EBF\uFF0C\u656C\u8BF7\u671F\u5F85");
		add(lblNewLabel);

	}

}
