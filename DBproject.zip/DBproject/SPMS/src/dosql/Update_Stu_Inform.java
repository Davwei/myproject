package dosql;

public class Update_Stu_Inform {

	public Update_Stu_Inform() {
		// TODO Auto-generated constructor stub
	}

}
