package dosql;

public class Update_Tea_Inform {

	public Update_Tea_Inform() {
		// TODO Auto-generated constructor stub
	}

}
