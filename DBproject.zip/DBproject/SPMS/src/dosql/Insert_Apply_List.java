package dosql;

public class Insert_Apply_List {

}
