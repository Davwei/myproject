package dosql;

public class Join_Team {
	String Stu;
	public Join_Team(){
		//desgin a new bit for underexamining
		String sql ="INERT INTO ``";
		
	}

}
