package dosql;

public class Select_Conclude_List {

	public Select_Conclude_List() {
		// TODO Auto-generated constructor stub
	}

}
