package dosql;

public class Update_Team_List {
	//I don't think the information should be deleted
	public Update_Team_List() {
		// TODO Auto-generated constructor stub
	}

}
