package utils;

public class Tea {
		public Tea(){
			
		}
}
