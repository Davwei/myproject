package utils;

public class Admin {
	public Admin(){
		
	}
}
