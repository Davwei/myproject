package utils;

public class Stu {
	String Stu_ID,Stu_Name;
	String Stu_Class;
	public String getStu_ID() {
		return Stu_ID;
	}
	public String getStu_Name() {
		return Stu_Name;
	}
	public String getStu_Class() {
		return Stu_Class;
	}
	public void setStu_ID(String stu_ID) {
		Stu_ID = stu_ID;
	}
	public void setStu_Name(String stu_Name) {
		Stu_Name = stu_Name;
	}
	public void setStu_Class(String stu_Class) {
		Stu_Class = stu_Class;
	}
	public Stu(){
		
	}
}
